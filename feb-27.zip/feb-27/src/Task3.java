import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Task3 {

	public static void main(String[] args) throws IOException {
//		C:\Users\rjaga\Pictures\vernon-l-smith-reading-alcove.jpg
		//to represent this file 
		File f=new File("C:\\Users\\rjaga\\Pictures\\vernon-l-smith-reading-alcove.jpg");
		
		int len=(int) f.length();
		byte []data=new byte[len];
		//to read bytes from a file, we use FileInputStream
		FileInputStream fis=new FileInputStream(f);
		fis.read(data);
		fis.close();
		
		/////////////////////////		create a new file and write all bytes to that file
		FileOutputStream fos=new FileOutputStream("D:\\Jag\\Java\\185\\debanjan.jpg");
		fos.write(data);
		new Scanner(System.in).next();
		
//		fos.close();		//close will call flush()
		System.out.println("Check");
	}

}
