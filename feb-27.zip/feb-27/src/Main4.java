import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class Main4 {

	public static void main(String[] args) throws IOException
	{
		File f=new File("D:\\Jag\\Java\\jyothika.txt");
		//read int, float and String. WHich class???	to read?
		DataInputStream dis=new DataInputStream(new FileInputStream(f));
		int i=dis.readInt();
		System.out.println(i);
		float f1=dis.readFloat();
		System.out.println(f1);
		String s=dis.readLine();
		System.out.println(s);
	}

}
