import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Main_Serialization 
{

	public static void main(String[] args) throws IOException{
		Employee employee=new Employee();
		employee.setEmployeeId(2421389);
		employee.setName("Badilanka Yaminiseshakala");
		employee.setBranch("CS");
		
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream("emp.dat"));
		oos.writeObject(employee);
		oos.flush();
		oos.close();
		System.out.println("Check the file");
	}

}
