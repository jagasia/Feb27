
//class Employee
//{
//	public Employee()
//	{
//		System.out.println("Employee object is created");
//	}
//}
public class Main7 {

	public static void main(String[] args) throws ClassNotFoundException {
//		Class.forName("Employee");
		System.out.println("Done");
	}

}
