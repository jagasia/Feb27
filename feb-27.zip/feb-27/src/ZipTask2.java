import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipTask2 {

	public static void main(String[] args) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Choose the folder to zip");
		String input=new Scanner(System.in).nextLine();
		File curr=new File(input);
		
		//if the path is invalid????
		if(!curr.exists())
		{
			System.out.println("Invalid path...");
			System.exit(0);
		}
		File[] files = curr.listFiles();
		
		ZipOutputStream zos=new ZipOutputStream(new FileOutputStream(input+"\\sangeetha.zip"));
		for(File f:files)
		{
			if(f.isDirectory())
				continue;
//			System.out.println(f.getName());
			zos.putNextEntry(new ZipEntry(f.getName()));
			
			//get all bytes from f and write them into zos
			int len=(int) f.length();
			byte[] data=new byte[len];
			FileInputStream fis=new FileInputStream(f);
			fis.read(data);
			fis.close();
			
			zos.write(data);
			zos.closeEntry();
		}
		zos.close();
	}

}
