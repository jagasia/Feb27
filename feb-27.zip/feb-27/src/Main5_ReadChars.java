import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Main5_ReadChars {

	public static void main(String[] args) throws IOException {
		File f=new File("d:\\jag\\java\\kaleshwar.txt");
		FileReader fr=new FileReader(f);
		int len=(int) f.length();
		char data[]=new char[len];
		fr.read(data);
		String s=new String(data);
		System.out.println(s);
	}

}
