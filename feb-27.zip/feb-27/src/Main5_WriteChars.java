import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main5_WriteChars {

	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		String input=sc.nextLine();
		//to write characters into a file
		FileWriter fw=new FileWriter("d:\\jag\\java\\kaleshwar.txt");
		fw.write(input);
		fw.flush();
		fw.close();
	}

}
