import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Date;
import java.util.Scanner;

public class Main_Stream1 {

	public static void main(String[] args) throws FileNotFoundException {
//		FileInputStream fis=new FileInputStream("D:\\Jag\\Java\\jyothika.txt");
		File f=new File("d:\\jag\\java\\jyothika.txt");
		System.out.println(f.length());
		long time=f.lastModified();
		Date dt=new Date();
		dt.setTime(time);
		System.out.println(dt);
		System.out.println(f.getAbsolutePath());
		
		
	}

}
