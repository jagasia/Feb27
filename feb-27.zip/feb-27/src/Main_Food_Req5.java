import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main_Food_Req5 {

	public static void main(String[] args) throws ParseException {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number of Purchase");
		int n=sc.nextInt();
		List<Item> itemList = Item.prefill();
		List<Purchase> purchaseList=new ArrayList<Purchase>();
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
		for(int i=0;i<n;i++)
		{
			System.out.println("Enter purchase detail "+(i+1));
//			1,FIRST,12-02-2018
			String detail=sc.nextLine();
			if(detail.equals(""))
				detail=sc.nextLine();
			String[] arr = detail.split(",");
			Purchase purchase=new Purchase();
			purchase.setId(Integer.valueOf(arr[0]));
			purchase.setCouponCode(arr[1]);
			
			purchase.setPurchaseDate(sdf.parse(arr[2]));
			System.out.println("Enter the number of Orders");
			int n2=sc.nextInt();
			for(int j=0;j<n2;j++)
			{
				String detail2=sc.nextLine();
				if(detail2.equals(""))
					detail2=sc.nextLine();
//				2,Grill
				String[] arr2 = detail2.split(",");
				Order order=new Order();
				order.setQuantity(Integer.valueOf(arr2[0]));
				//arr[1] is the item name. But we need Item object
				for(Item item:itemList)
				{
					if(item.getName().equals(arr2[1]))
						order.setItem(item);
				}
				//add this order object to the purchase
				purchase.getOrderList().add(order);				
			}
			purchaseList.add(purchase);
		}
		Purchase.computePrice(purchaseList);
		System.out.format("%-5s %-10s %-12s %s\n","Id","Price","Coupon Code","Purchase Date");
		for(Purchase p:purchaseList)
			System.out.format("%-5s %-10s %-12s %s\n",p.getId(),p.getPrice(),p.getCouponCode(),sdf.format(p.getPurchaseDate()));

	}

}
