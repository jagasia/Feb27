
public class Main_Assertions {

	public static void main(String[] args) {
		int i=20;
		int j=30;
		i+=j;
		assert i>60;
		System.out.println(i);
		if(20>10)
		{
			System.out.println(j);
		}
	}

}
