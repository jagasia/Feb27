class InvalidPinException extends NumberFormatException
{	
	public InvalidPinException(String message)
	{
		super(message);
	}
}

class Bank
{
	Boolean validatePin(String pin)
	{
		Boolean isValid=true;
		if(pin.length()!=4)
		{
			isValid=false;
		}else
		{
			StringBuilder sb=new StringBuilder(pin);
			String reverse=sb.reverse().toString();
			if(pin.equals(reverse))
			{
				isValid=false;
			}else
			{
				//length is 4. ALso it is palindrome. Check if all are numbers
				//1) regex pattern matches
				//2) loop the characters and check if every char is digit
				//3) use Integer.parseInt surrounded by try catch
				try
				{
					Integer.parseInt(pin);
				}catch(Exception ex)
				{
					isValid=false;
				}
			}
		}
		if(!isValid)
			throw new InvalidPinException("The pin you have entered is invalid");
		return true;
	}
}

public class ExceptionTask2 {

	public static void main(String[] args) {
		Bank sbi=new Bank();
		Boolean result = sbi.validatePin("12345");
		System.out.println(result);
	}

}
