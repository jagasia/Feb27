import java.util.InputMismatchException;
import java.util.Scanner;

public class Exception_Task1 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int i=0;
		int j=0;
		String name="";
		int result=0;
		int k=0;

		i=sc.nextInt();
		try {
			j=sc.nextInt();
			result=i/j;
		}catch(ArithmeticException ae)
		{
			System.out.println(ae);
		}
		catch(InputMismatchException ime)
		{
			System.out.println(ime);
		}
		name=sc.nextLine();
		k=sc.nextInt();


		System.out.println(name);
		System.out.println(result);
	}

}
