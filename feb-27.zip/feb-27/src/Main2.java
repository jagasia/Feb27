import java.io.File;

public class Main2 {

	public static void main(String[] args) {
		File f=new File("d:\\jag");
		//list out all the files present in this folder
//		String[] list = f.list();
//		for(String x:list)
//			System.out.println(x);
		File[] list1 = f.listFiles();
		for(File x : list1)
		{
			System.out.println(x.getName()+" is a "+(x.isDirectory()?"Folder":"File"));
		}
	}

}
