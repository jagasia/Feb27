import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main3 {

	public static void main(String[] args) throws IOException
	{
		File f=new File("D:\\Jag\\Java\\jyothika.txt");
		//i want to write an int, a float and a String
		//which class can i use. Since primitives are there, i use data output stream
		DataOutputStream dos=new DataOutputStream(new FileOutputStream(f));
		//we borrow the functionality from Data Outputstream (what functionality? writing primitive types)
		dos.writeInt(250);
		dos.writeFloat(12.36f);
		dos.writeChars("Rama");
		////	here, the program ends when last line is executed
		dos.flush();			//this method forces the data in memory to store in secondary storage
		//but flush method is called when we use close() method also
		//close() method is automatically called when the program ends normally
		//but when the program does not end (Swing/applet), the flush method does not call automatically
		dos.close();
	}

}
