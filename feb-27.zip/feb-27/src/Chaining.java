import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Chaining {

	public static void main(String[] args) throws IOException {
		//we retrieve input from user as String		(Reader)
		//Reader is abstract. so any of its sub class
		//are we going to read from File? No. So not FileReader. We are going to read from???
		//keyboard. Keyboard is represented by System.in
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String input=br.readLine();
		System.out.println(input);
		
//		BufferedInputStream bis=new BufferedInputStream(System.in);
//
		
	}

}
