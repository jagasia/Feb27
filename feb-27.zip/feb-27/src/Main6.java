import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main6 {

	public static void main(String[] args) throws InterruptedException, IOException{
		File f=new File("C:\\Users\\rjaga\\Pictures\\jag_profile.jpg");
		FileInputStream fis=new FileInputStream(f);
		int data=-1;
		FileOutputStream fos=new FileOutputStream("D:\\Jag\\Java\\185\\jag.jpg");
		while((data=fis.read())!=-1)
		{
			fos.write(data);
//			Thread.sleep(1);
		}
		System.out.println("Check now");
	}
}
