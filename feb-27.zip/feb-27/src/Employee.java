import java.io.Serializable;

public class Employee implements Serializable

{
	private Integer employeeId;
	private String name;
	private String branch;
	public Employee() {}
	public Employee(Integer employeeId, String name, String branch) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.branch = branch;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", branch=" + branch + "]";
	}
	
}
