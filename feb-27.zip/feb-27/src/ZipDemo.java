import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class ZipDemo {

	public static void main(String[] args) throws IOException {
//		D:\Jag\Java\185
		ZipOutputStream zos=new ZipOutputStream(new FileOutputStream("D:\\Jag\\Java\\185\\harsha.zip"));
		//i) create an entry name
		//ii) create file and write bytes into the file
//		ZipEntry ze=new ZipEntry("jag.jpg");
		zos.putNextEntry(new ZipEntry("jag.jpg"));
		
		File f=new File("D:\\Jag\\Java\\185\\jag.jpg");
		int len=(int) f.length();		
		FileInputStream fis=new FileInputStream(f);
		byte []data=new byte[len];
		fis.read(data);
		
		zos.write(data);
		zos.closeEntry();
		
		
		zos.close();
		System.out.println("Check");
	}

}
